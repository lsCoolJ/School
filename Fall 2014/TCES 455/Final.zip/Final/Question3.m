t = 8
r = 3
A = pi*r^2
h = 14
R = -(t/(A * log(1/h)))
Answer = 1/(A * R)